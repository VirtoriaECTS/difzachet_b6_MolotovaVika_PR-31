package com.example.div_zachet


import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class screenStatistick : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen_statistick)

        val sharedPreferences = getSharedPreferences("factT", MODE_PRIVATE)

        val savedfact = sharedPreferences.getString("fact", "")

        val textFact = findViewById<TextView>(R.id.factSaveText)
        textFact.text = savedfact

    }

    fun saveBut(view: View) {
        val textFact = findViewById<TextView>(R.id.factSaveText)
        val sharedPreferences = getSharedPreferences("factT", MODE_PRIVATE)
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putString("fact", textFact.toString())

    }

    fun deleteBut(view: View) {
        val textFact = findViewById<TextView>(R.id.factSaveText)
        textFact.text = ""
        val sharedPreferences = getSharedPreferences("factT", MODE_PRIVATE)
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putString("fact", textFact.toString())

    }
}