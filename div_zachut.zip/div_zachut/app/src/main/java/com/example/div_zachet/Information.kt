package com.example.div_zachet

import android.content.Intent
import android.content.SharedPreferences

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class Information : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_information)
    }

    fun getResult(query: String) {

        val date = "2023-10-25"
        val apiKey = "qQ3BSWMVpHSjjMSg4q3ppx5GujWMxZOjIeUQKPhI"
        val lowercaseQuery = query.toLowerCase()
        val url = when (lowercaseQuery) {
            "apod" -> "https://api.nasa.gov/planetary/apod?api_key=$apiKey"
            "neo" -> "https://api.nasa.gov/neo/rest/v1/neo/browse?api_key=$apiKey"
            else -> "https://api.nasa.gov/planetary/apod?api_key=$apiKey&date=$date"
        }

        val queue: RequestQueue = Volley.newRequestQueue(this)
        val stringRequest = StringRequest(
            Request.Method.GET,
            url,
            { response ->
                try {
                    val obj = JSONObject(response)
                    val title = obj.getString("title")
                    val explanation = obj.getString("explanation")
                    val imageUrl = obj.getString("url")

                    val textFact = findViewById<TextView>(R.id.textVivod)


                    textFact.text = title + "\n" + explanation + "\n" + explanation + "\n" + imageUrl

                    val sharedPreferences = getSharedPreferences("factT", MODE_PRIVATE)
                    val editor: SharedPreferences.Editor = sharedPreferences.edit()

                    editor.putString("fact", textFact.text.toString())
                    editor.apply()

                } catch (e: Exception) {
                    e.printStackTrace()
                }
            },
            { error ->
                Toast.makeText(this, "Error: $error", Toast.LENGTH_SHORT).show()
            }
        )
        queue.add(stringRequest)
    }

    fun perehod(view: View) {
        val intent = Intent(this@Information, screenStatistick::class.java)
        startActivity(intent)
    }

    fun ButtonGetResult(view: View) {
        val text = findViewById<EditText>(R.id.editText)
        getResult(text.text.toString());


    }
}